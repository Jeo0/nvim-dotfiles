return {
    "neovim/nvim-lspconfig",
    event = { "BufReadPre", "BufNewFile" },
    cmd = { "LspInstall", "LspUninstall" },
    dependencies = {
        "hrsh7th/cmp-nvim-lsp",
        "williamboman/mason.nvim",
        "williamboman/mason-lspconfig.nvim",
        "ray-x/lsp_signature.nvim",
    },
    config = function()
        local mason_lspconfig = require("mason-lspconfig")

        -- Rounded borders on ALL LSP floating windows (hover, signature, diagnostics).
        -- vim.lsp.with() was REMOVED in Nvim 0.12; vim.o.winborder is the replacement.
        vim.o.winborder = "rounded"

        -- Mason only handles installation here; enabling is done explicitly below
        -- via vim.lsp.enable(), which is the nvim-lspconfig >=0.11 way of doing things
        -- (require('lspconfig').X.setup() is deprecated and goes away in v3.0.0).
        mason_lspconfig.setup({
            ensure_installed = {
                "clangd",  -- C / C++
                "pyright", -- Python
                "lua_ls",  -- Lua (for editing your own config)
            },
        })

        local capabilities = require("cmp_nvim_lsp").default_capabilities()

        -- Shared on_attach logic now runs off the LspAttach autocmd instead of
        -- being passed into each server's setup() call.
        local on_attach = function(client, bufnr)
            local opts = { buffer = bufnr, silent = true }

            vim.keymap.set('n', 'K', vim.lsp.buf.hover, opts)
            vim.keymap.set('n', 'gd', vim.lsp.buf.definition, opts)
            vim.keymap.set('n', '<C-]>', vim.lsp.buf.definition, opts)          -- old ctags key → LSP
            vim.keymap.set('n', 'gD', vim.lsp.buf.declaration, opts)
            vim.keymap.set('n', 'gi', vim.lsp.buf.implementation, opts)
            vim.keymap.set('n', 'gr', vim.lsp.buf.references, opts)
            vim.keymap.set('n', '<leader>rn', vim.lsp.buf.rename, opts)
            vim.keymap.set('n', '<leader>ca', vim.lsp.buf.code_action, opts)
            vim.keymap.set('i', '<C-k>', vim.lsp.buf.signature_help, opts)

            require("lsp_signature").on_attach({
                bind = true,
                handler_opts = { border = "rounded" },
                hint_enable = false,
            }, bufnr)

            -- Format on save logic (left disabled on purpose)
            -- if client.server_capabilities.documentFormattingProvider then
            --     vim.api.nvim_create_autocmd("BufWritePre", {
            --         buffer = bufnr,
            --         callback = function() vim.lsp.buf.format() end,
            --     })
            -- end
        end

        vim.api.nvim_create_autocmd("LspAttach", {
            group = vim.api.nvim_create_augroup("UserLspAttach", { clear = true }),
            callback = function(args)
                local client = vim.lsp.get_client_by_id(args.data.client_id)
                on_attach(client, args.buf)
            end,
        })

        -- ── C / C++ ────────────────────────────────────────────────────────────
        -- Needs compile_commands.json at project root for cross-file navigation.
        -- Generate: cmake -DCMAKE_EXPORT_COMPILE_COMMANDS=ON ..
        --       or: bear -- make
        vim.lsp.config('clangd', {
            capabilities = capabilities,
            cmd = {
                "clangd",
                "--background-index",
                "--clang-tidy",
                "--header-insertion=iwyu",
            },
        })

        -- ── Python ─────────────────────────────────────────────────────────────
        vim.lsp.config('pyright', {
            capabilities = capabilities,
        })

        -- ── Lua ────────────────────────────────────────────────────────────────
        vim.lsp.config('lua_ls', {
            capabilities = capabilities,
            settings = {
                Lua = {
                    diagnostics = { globals = { "vim" } },
                },
            },
        })

        -- ── Godot GDScript ─────────────────────────────────────────────────────
        -- Not managed by Mason; the LSP lives inside Godot (port 6005).
        -- Godot must be open with LSP enabled in Editor Settings → Network → Language Server.
        vim.lsp.config('gdscript', {
            capabilities = capabilities,
        })

        vim.lsp.enable({ "clangd", "pyright", "lua_ls", "gdscript" })
    end,
}
